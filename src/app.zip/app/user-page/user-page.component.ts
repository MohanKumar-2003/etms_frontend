// import { HttpClient } from '@angular/common/http';
// import { Component, OnInit } from '@angular/core';
// import { UserdetailsService } from '../userdetails.service';
// import { Router } from '@angular/router';
// import { ManagerdetailsService } from '../managerdetails.service';
// import { MasterserviceService } from '../masterservice.service';
// import { AdmindetailsService } from '../admindetails.service';

// @Component({
//   selector: 'app-user-page',
//   templateUrl: './user-page.component.html',
//   styleUrls: ['./user-page.component.css']
// })
// export class UserPageComponent implements OnInit{
 
 
//   dtOptions: DataTables.Settings = {};
//   users: any[] = []; // Your data goes here
 
//   gbl:any[]=['FS','MS','MTS','CTOO']
 
//   proj_id:number=0
//   pro_name:string=''
//   emp_group:string=''
//   userskills:any[]=[]
//   projects:any[]=[]
//   skill_name:string=''
//   skills:any[]=[]
//   skillids:number[]=[]
//   selectedSkills:any[]=[]
//   needtoTrainskill:any[]=[]
//   needtoTrainskillids:any[]=[]
//   projectskills:any[]=[]
//   userProjects: { [key: number]: string } = {};
// userSkills: { [key: number]: string[] } = {};
// userProjectSkills:{ [key: number]: string[] }={}
// dept:string=''
//   i:any[]=[]
//   skill:any[]=[]
//   id:number=0
//   check:boolean=true
//   selectedUser:any
 
//   userSk:{ [key: number]: any[] }={}
//   userSkillids:{ [key: number]: any[] }={}
//   constructor(
//     private authService: UserdetailsService,
//     private router: Router,
//     private adminService:ManagerdetailsService,

//   ) {
    
   
//   }
//   logout(): void {
//     this.authService.loggedout();
//     this.router.navigate(['/login']);
//   }
 
 
//   ngOnInit(): void {
//     this.getEmployees()
//     this.getProjects()
//     this.getSkills()
   
   
//   }

 
 
 
//   getEmployees():any[]{
//   this.adminService.getUsers().subscribe((res)=>{
//     for(let user of res){
//      if(user.role_name=='USER' && user.assign_status=='No'){
//        this.users.push(user)
       
     
//        if (this.users.length > 0) {
       
//       }
//    console.log(this.users)
//      }
     
//     }
//     for(let i of this.users){
//       this.userSk[i.user_id]=i.employeeskills.map((skill: { skillName: any; })=>skill.skillName)
//       console.log(this.userSk[i.user_id])
//     }
   
// })
// return this.users
// }
 

// getProjects():any[]{
//   this.adminService.getProjects().subscribe((res)=>{
//     for(let i of res){
//         this.projects.push(i)
//     }
//   })
//   console.log(this.pro_name)
//   return this.projects;
// }
 
// getSkills():any[]{
//   this.adminService.getSkills().subscribe((res)=>{
//     this.skills=res
//   })
//   console.log(this.skills)
//   return this.skills;
// }
 


// }
 

import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { UserdetailsService } from '../userdetails.service';
import { Router } from '@angular/router';
import { ManagerdetailsService } from '../managerdetails.service';

@Component({
  selector: 'app-user-page',
  templateUrl: './user-page.component.html',
  styleUrls: ['./user-page.component.css']
})
export class UserPageComponent implements OnInit {
  users: any[] = [];
  dtOptions: DataTables.Settings = {};
  loggedInUser: any;
  gbl: any[] = ['FS', 'MS', 'MTS', 'CTOO'];
  projects: any[] = [];
  skills: any[] = [];
  userProjects: { [key: number]: string } = {};
  userSkills: { [key: number]: string[] } = {};
  id: number = 0;

  constructor(
    private authService: UserdetailsService,
    private router: Router,
    private adminService: ManagerdetailsService,
    private userService: UserdetailsService
  ) {}

  ngOnInit(): void {
    this.loadLoggedInUser();
    this.getProjects();
    this.getSkills();
    // Other initialization logic
  }

  loadLoggedInUser(): void {
    const username = this.userService.getUsername();
    if (username) {
      this.userService.getempdetailsByName(username).subscribe((res: any) => {
        this.loggedInUser = res;
        this.id = this.loggedInUser.user_id;
        this.userService.getneedtoTrainskills(this.id).subscribe((skillsRes: any) => {
          this.skills = skillsRes.skills;
        });
        // Additional logic for loading projects if needed
      });
    }
  }

  getProjects(): void {
    this.adminService.getProjects().subscribe((res) => {
      this.projects = res;
    });
  }

  getSkills(): void {
    this.adminService.getSkills().subscribe((res) => {
      this.skills = res;
    });
  }

  logout(): void {
    this.authService.loggedout();
    this.router.navigate(['/login']);
  }
}










































// {
//   id:number=0;
//   users: any[] = []; 
 
//   gbl:any[]=['FS','MS','MTS','CTOO']
 
//   proj_id:number=0
//   pro_name:string=''
//   emp_group:string=''
//   userskills:any[]=[]
//   projects:any[]=[]
//   skill_name:string=''
//   skills:any[]=[]
//   skillids:number[]=[]
//   selectedSkills:any[]=[]
//   needtoTrainskill:any[]=[]
//   needtoTrainskillids:any[]=[]
//   userProjects: { [key: number]: string } = {};
// userSkills: { [key: number]: string[] } = {};
// dept:string=''
//   i:any[]=[]
//   skill:any[]=[]

//   check:boolean=true
//   selectedUser:any
// constructor(private http:HttpClient,  private authService: UserdetailsService,
//   private router: Router,private userService:UserdetailsService, private adminService:AdmindetailsService,private manager:ManagerdetailsService){
    
 

// }
// ngOnInit(): void {
//   this.loaduser();
//    this.getProjects();
//    this.getSkills();
    
// }


// name:any=this.userService.getUsername()
 
// data:string=''

// loaduser():any{
// this.userService.getempdetailsByName(this.name).subscribe((res:any)=>{
//   this.id=res.user_id
//   console.log(this.id)
//   console.log(res.username)
//   this.userService.getneedtoTrainskills(this.id).subscribe((res:any)=>{
//     this.skills=res.skills
//   })
//   this.manager.getProjects().subscribe((res)=>{
//     for(let i of res){
//       if(i.pro_status===false){
//         this.projects.push(i)
//       }
//     }
//   })
//   console.log(this.pro_name)
//   return this.projects;
// })
// }
// getSkills(){
//   this.userService.getneedtoTrainskills(this.id).subscribe((res:any)=>{
//     this.skills=res
//   })
// }
// getProjects():any[]{
//   this.manager.getProjects().subscribe((res)=>{
//     for(let i of res){
//       if(i.pro_status===false){
//         this.projects.push(i)
//       }
//     }
//   })
//   console.log(this.pro_name)
//   return this.projects;
// }
 
// logout(): void {
//   this.authService.loggedout();
//   this.router.navigateByUrl('/login'); 
// }


// getEmployees():any[]{
//   this.adminService.getUsers().subscribe((res)=>{
//     for(let user of res){
//      if(user.role_name=='USER' && user.assign_status=='No'){
//        this.users.push(user)
     
//    console.log(this.users)
//      }
     
//     }
   
// })
// return this.users
// }
// }